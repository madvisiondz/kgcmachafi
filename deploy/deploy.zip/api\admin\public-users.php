<?php
declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method === 'GET') {
    require_admin();

    $query = trim((string) ($_GET['q'] ?? ''));
    $limit = (int) ($_GET['limit'] ?? 200);
    $limit = max(1, min($limit, 500));

    if ($query !== '') {
        $like = '%' . $query . '%';
        $statement = db()->prepare(
            'SELECT id, email, full_name, phone, wilaya_id, commune, role, is_active, created_at
             FROM public_users
             WHERE email LIKE :q OR full_name LIKE :q OR phone LIKE :q
             ORDER BY created_at DESC
             LIMIT ' . $limit
        );
        $statement->execute(['q' => $like]);
    } else {
        $statement = db()->prepare(
            'SELECT id, email, full_name, phone, wilaya_id, commune, role, is_active, created_at
             FROM public_users
             ORDER BY created_at DESC
             LIMIT ' . $limit
        );
        $statement->execute();
    }

    json_response(['items' => $statement->fetchAll()]);
}

if ($method === 'PUT') {
    $admin = require_admin();

    if (($admin['role'] ?? '') !== 'admin') {
        json_response(['message' => 'غير مصرح بتعديل أدوار المستخدمين.'], 403);
    }

    $id = (int) ($_GET['id'] ?? 0);
    if ($id <= 0) {
        json_response(['message' => 'معرّف المستخدم غير صالح.'], 422);
    }

    $payload = read_json_input();
    $role = trim((string) ($payload['role'] ?? ''));

    // Allowed roles for public users in this feature.
    $allowedRoles = ['member', 'editor', 'moderator'];
    if (!in_array($role, $allowedRoles, true)) {
        json_response(['message' => 'الدور غير صالح.'], 422);
    }

    $update = db()->prepare('UPDATE public_users SET role = :role WHERE id = :id');
    $update->execute(['role' => $role, 'id' => $id]);

    $fetch = db()->prepare(
        'SELECT id, email, full_name, phone, wilaya_id, commune, role, is_active, created_at
         FROM public_users
         WHERE id = :id
         LIMIT 1'
    );
    $fetch->execute(['id' => $id]);

    json_response([
        'message' => 'تم تحديث دور المستخدم.',
        'user' => $fetch->fetch(),
    ]);
}

json_response(['message' => 'الطريقة غير مدعومة.'], 405);

